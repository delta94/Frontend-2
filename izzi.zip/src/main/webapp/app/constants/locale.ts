export const LOCALE_ACTION_TYPES = {
  SET_LOCALE: 'locale/SET_LOCALE'
};

