import styled from 'styled-components'

export default styled.img`
  border: 0;
  display: block;
  max-width: 100%;
  width: 100%;
`
