import 'react-toastify/dist/ReactToastify.css';
import './app.scss';

import React from 'react';
import { connect } from 'react-redux';
import { Card } from 'reactstrap';
import { HashRouter as Router } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import { hot } from 'react-hot-loader';

import { IRootState } from 'app/reducers';
import { setLocale } from 'app/actions/locale';
import { getSession } from 'app/actions/authentication';
import Header from 'app/layout/header/header';
import Footer from 'app/layout/footer/footer';
import Sidebar from 'app/layout/sidebar/sidebar';

import ErrorBoundary from 'app/common/error/error-boundary';
import { hasAnyAuthority } from 'app/common/auth/private-route';
import { AUTHORITIES } from 'app/config/constants';
import AppRoutes from 'app/routes/routes';
import Main from './DemoPages/Main';
const baseHref = document
  .querySelector('base')
  .getAttribute('href')
  .replace(/\/$/, '');

export interface IAppProps extends StateProps, DispatchProps {}
export interface IAppState {
  height: number;
  width: boolean;
}
export class App extends React.Component<IAppProps, IAppState> {
  state: IAppState = {
    height: null,
    width: true
  };

  componentDidMount() {
    this.props.getSession();
    var height = window.innerHeight;
    this.setState({
      height: height
    });
    this.updateDimensions();
    window.addEventListener('resize', this.updateDimensions);
  }
  updateDimensions = () => {
    if (window.innerWidth <= 576 || window.innerWidth <= 768) {
      this.setState({ width: false });
    } else {
      this.setState({ width: true });
    }
  };
  componentWillUnmount() {
    window.removeEventListener('resize', this.updateDimensions);
  }
  render() {
    const { isAuthenticated } = this.props;
    const paddingTop = '98px';
    return (
      <Router basename={baseHref}>
        {isAuthenticated ? (
          <div className="app-container">
            {/* <ToastContainer position={toast.POSITION.TOP_RIGHT} className="toastify-container" toastClassName="toastify-toast" />
            <ErrorBoundary>
              <Header
                isAuthenticated={this.props.isAuthenticated}
                currentLocale={this.props.currentLocale}
                onLocaleChange={this.props.setLocale}
                username={this.props.account.name}
              />
            </ErrorBoundary>
            <div className="container-fluid view-container" id="app-view-container">
              <div className="app-content-container">
                <Sidebar show={this.state.width} {...this.props} />
                <Card className="open jh-card" id="jh-card" style={{ height: this.state.height + 'px' }}>
                  <ErrorBoundary>
                    <AppRoutes />
                  </ErrorBoundary>
                </Card>
                <Footer />
              </div>
            </div> */}
          </div>
        ) : (
          Main
          // <Switch>
          //   <ErrorBoundaryRoute path="/" component={Login} />
          // </Switch>
        )}
      </Router>
    );
  }
}

const mapStateToProps = ({ authentication, locale }: IRootState) => ({
  currentLocale: locale.currentLocale,
  isAuthenticated: authentication.isAuthenticated,
  isAdmin: hasAnyAuthority(authentication.account.roles, [AUTHORITIES.ADMIN]),
  isConverter: hasAnyAuthority(authentication.account.roles, [AUTHORITIES.CONVERTER]),
  isInterviewer: hasAnyAuthority(authentication.account.roles, [AUTHORITIES.INTERVIEWER]),
  account: authentication.account
});

const mapDispatchToProps = { setLocale, getSession };

type StateProps = ReturnType<typeof mapStateToProps>;
type DispatchProps = typeof mapDispatchToProps;

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(hot(module)(App));
